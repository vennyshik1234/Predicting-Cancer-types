## README

**Cancer Type Prediction**

This project provides a Python code for cancer type prediction using the three cancer datasets you provided. The code is divided into three parts:

1. **Data loading:** This section loads the three cancer datasets into Pandas DataFrames.
2. **Model training:** This section trains the three machine learning models on the combined dataset.
3. **Model evaluation:** This section evaluates the performance of the three machine learning models on the test set.

## Usage

To use the code, simply run the following command:

```
python cancer_prediction.py
```

This will train and evaluate the three machine learning models on the three cancer datasets. The accuracy scores for each model will be printed to the console.

```

## Requirements

* Python 3
* Pandas
* Scikit-learn

## Installation

To install the requirements, run the following command:

```
pip install pandas scikit-learn

```######### Usage ################


**Data loading:** The first section of the code loads the three cancer datasets into Pandas DataFrames. The datasets are loaded using the `pandas.read_csv()` function.


**Model training:** The second section of the code trains the three machine learning models on the combined dataset. The three models that are trained are:

* Support vector machine (SVM)
* Random forest
* Neural network

The models are trained using the `sklearn.svm.SVC()`, `sklearn.ensemble.RandomForestClassifier()`, and `sklearn.neural_network.MLPClassifier()` functions, respectively.
 
############# License ####################
This project is licensed under the MIT License. Please see the LICENSE file for more information.


